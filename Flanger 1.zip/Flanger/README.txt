Il plugin progettato è un effetto VST di tipo Flanger, con diverse opzioni configurabili per modellare il suono. La sua architettura principale è suddivisa in quattro sezioni funzionali:

Delay e Feedback

Il cuore del flanger consiste nel ritardare il segnale in ingresso.

I parametri principali sono Delay Time e Feedback, che determinano rispettivamente il tempo di ritardo e la quantità di segnale ritardato reinserita nel buffer.

Modulazione tramite LFO

Essendo un flanger, il segnale ritardato viene modulato usando un LFO (Low Frequency Oscillator).

L’utente può controllare:

Amount / Depth: l’intensità della modulazione.

Waveform: forma d’onda dell’LFO (Sine, Triangle, Saw, Square, ecc.).

Phase Delta: sfasamento della modulazione tra i canali stereo per creare effetti di spazializzazione.

Filtro opzionale

Il segnale modulato può essere passato attraverso un filtro.

Parametri configurabili:

Cutoff: frequenza di taglio del filtro.

Quality / Resonance: risonanza del filtro.

Tipo di filtro: LowPass, HighPass, BandPass.

Il filtro può essere attivato o disattivato a discrezione dell’utente.

Mix & Gain

Gestione del Dry/Wet per bilanciare il segnale originale e il segnale processato.

Controllo del Gain di uscita per regolare il volume complessivo del plugin.

inoltre per rendere il plugin più user-friendly sono stati aggiunti i pulsanti per undo/redo delle modifiche dei parametri

Gestione del segnale stereo

Il plugin supporta il trattamento stereo, consentendo di applicare il phase delta nella modulazione.

Questo permette di sfasare la modulazione tra i due canali, aumentando la sensazione di movimento e spazialità del flanger.